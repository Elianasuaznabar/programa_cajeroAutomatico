/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ventanas;

/**
 *
 * 
 */
public class EstadoComboBox {
   
    
    private static int indiceSeleccionado = 0;

    public static void setIndiceSeleccionado(int indice) {
        indiceSeleccionado = indice;
    }

    public static int getIndiceSeleccionado() {
        return indiceSeleccionado;
    }
}
