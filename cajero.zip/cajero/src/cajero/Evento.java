/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cajero;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 *
 */
public class Evento {

    private String nroCuenta;
    private String descripcion;
    private String monto;
    private String saldo;
    
    /**
     * constructor de la clase Evento
     * @param nroCuenta
     * @param descripcion
     * @param monto
     * @param saldo 
     */
    public Evento(String nroCuenta, String descripcion, String monto, String saldo) {
        this.nroCuenta = nroCuenta;
        this.descripcion = descripcion;
        this.monto = monto;
        this.saldo = saldo;
    }
    /**
     * método público getNroCuenta
     * @return el nro de Cuenta
     */
    public String getNroCuenta() {
        return nroCuenta;
    }
    /**
     * método público getDescripcion
     * @return descripcion del movimiento del cajero
     */
    public String getDescripcion() {
        return descripcion;
    }
    
    /**
     * método público getMonto
     * @return el monto
     */
    public String getMonto() {
        return monto;
    }
    

    /**
     * método público getSaldo 
     * @return el saldo
     */
    public String getSaldo() {
        return saldo;
    }
    /**
     * método público getFecha
     * @return el formato de la fecha
     */

    public String getFecha() {
        LocalDate fechaActual = LocalDate.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String fechaFormateada = fechaActual.format(formato);
        return fechaFormateada;
    }
}
