/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * Proyecto de un ejemplo de cajero automático
 */
package cajero; 
/**
 * Clase que se encarga de definir variables de tipo privado
 */

public class Cuenta {

    private String nroCuenta;
    private String divisa;
    private String monto;
    /**
     * Constructor de la clase Cuenta
     * @param nroCuenta
     * @param divisa
     * @param monto 
     */
    public Cuenta(String nroCuenta, String divisa, String monto) {
        this.nroCuenta = nroCuenta;
        this.divisa = divisa;
        this.monto = monto;
       
    }
    /**
     * Método público getNroCuenta
     * @return 
     */

    public String getNroCuenta() {
        return nroCuenta;
    }
    
    /**
     * Método público getDivisa
     * @return 
     */
    public String getDivisa() {
        return divisa;
    }
    
    /**
     * Método público getMonto
     * @return 
     */
    public String getMonto() {
        return monto;
    }
    /**
     * Método toString
     * @return 
     */
    
    public String toString(){
        return nroCuenta + "("+ getDivisa()+ ")";
    }
}
