/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testing;

/**
 *
 *
 */
public class prueba {
    public static void main(String args[]){
        char[] ejemplo = {'a', 'b', 'c'};
        String cadena = String.valueOf(ejemplo);
        System.out.println(cadena);
    }
}
